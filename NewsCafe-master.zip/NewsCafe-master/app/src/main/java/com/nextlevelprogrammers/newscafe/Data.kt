package com.nextlevelprogrammers.newscafe

data class Data(
    val urlToImage:String,
    val url:String,
    val title:String,
    val author:String
)